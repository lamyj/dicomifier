.. Dicomifier documentation master file, created by
   sphinx-quickstart on Fri Jul  4 09:19:39 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Dicomifier's documentation!
======================================

Contents:

.. toctree::
   :maxdepth: 2

   start/index
   documentation/index
   downloads/index
   internal_wiki/index
   contact/index
   glossary/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

