Dicomifier's documentation
==========================

Contents:

.. toctree::
   :maxdepth: 2

   installation_guide
   user_guide
   dev_guide
   tutorial
   faq
