About Dicomifier
================

Dicomifier is an Open Source tool, created for the FLI project.

Dicomifier creates enhanced DICOM files from another file type, like DICOM files or Bruker files.
It allows to add Private Dictionaries.
