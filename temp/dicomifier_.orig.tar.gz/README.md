# dicomifier

Tools to manipulate DICOM files and generate DICOM from Bruker data.
